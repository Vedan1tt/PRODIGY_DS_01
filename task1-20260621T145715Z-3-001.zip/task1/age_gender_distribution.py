import matplotlib.pyplot as plt

# ── CHART 1: Age Distribution (Histogram) ───────────────────
ages = [5, 12, 18, 22, 25, 27, 30, 32, 35, 38, 40, 42, 45,
        48, 50, 52, 55, 58, 60, 63, 67, 70, 74, 78, 82]

plt.figure(figsize=(8, 5))
plt.hist(ages, bins=5, color="steelblue", edgecolor="white")
plt.title("Age Distribution in a Population")
plt.xlabel("Age")
plt.ylabel("Number of People")
plt.savefig("chart_age_distribution.png", dpi=150)
plt.show()
print("Age chart saved!")

# ── CHART 2: Gender Distribution (Bar Chart) ────────────────
genders = ["Male", "Female", "Other"]
counts  = [530, 460, 10]

plt.figure(figsize=(6, 5))
plt.bar(genders, counts, color=["steelblue", "salmon", "gray"])
plt.title("Gender Distribution in a Population")
plt.xlabel("Gender")
plt.ylabel("Number of People")
plt.savefig("chart_gender_distribution.png", dpi=150)
plt.show()
print("Gender chart saved!")
