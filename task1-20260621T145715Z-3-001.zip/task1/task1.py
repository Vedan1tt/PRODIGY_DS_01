import pandas as pd
import matplotlib.pyplot as plt

# Load the file
df = pd.read_csv("API_SP.POP.TOTL_DS2_en_csv_v2_282912.csv", skiprows=4)

# Pick 5 countries and the year 2023
countries = ["India", "China", "United States", "Brazil", "Nigeria"]
df = df[df["Country Name"].isin(countries)][["Country Name", "2023"]]

# Divide by 1 billion
df["2023"] = df["2023"] / 1_000_000_000

# Draw the bar chart
plt.bar(df["Country Name"], df["2023"], color="steelblue")
plt.title("Population in 2023")
plt.ylabel("Population (billions)")
plt.show()